#Exception for ZeroDivisionError
print("Enter the values for division")
a = int(input())
b = int(input())
try:
    print(a/b)
except ZeroDivisionError:
    print("A number cannot be divided by zero")

print("Enter a numeric string")
a = input()
try:
    print(a/3)
except TypeError:
    print("A string cannot be divided by a integer directly. Convert the type of string to integer to perform the operation")

#If you don't know which type of exception to raise, don't specify the exception name

print("Enter a file you want to read")
a = input()
try:
    f = open(a, "r")
    m = f.read()
    print("This is the content of your file")
    print(m)

except:
    print("This file is not present in the current directory")
finally:
    print("Finally it is executed like a common print statement.")

#We can also raise a exception using raise keyword
print("I am trying to raise an exception")
try:
    raise Myerror("I purposely tried to raise this exception")
except:
    print("Myerror is not a defined exception")