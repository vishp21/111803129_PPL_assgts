bank1 = {"goat", "grass", "tiger"}
bank2 = set()
current_bank = 'a'
not_allowed1 = {"goat", "tiger"}
not_allowed2 = {"goat", "grass"}
#last = str()
while len(bank1) > 0 :
	if current_bank == 'a' :
		if len(bank1) == 3 :
			x = bank1.pop()
			if (bank1 != not_allowed1) and (bank1 != not_allowed2) :
				print(x.capitalize() + " is taken from bank 1 to bank 2.")
				bank2.add(x)
				current_bank = 'b'
			else :
				bank1.add(x)
		else :
			x = bank1.pop()
			print(x.capitalize() + " is taken from bank 1 to bank 2.")
			bank2.add(x)
			current_bank = 'b'
	else :
		if (bank2 != not_allowed1) and (bank2 != not_allowed2) :
			print("The farmer returns alone.")
		else :
			x = bank2.pop()
			print(x.capitalize() + " is taken from bank 2 to bank 1.")
			bank1.add(x)
		current_bank = 'a'