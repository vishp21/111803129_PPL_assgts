a = [1,3,5,6,8,10,12,13,15,17,19,20,22,24]
b = []

for i in range(1, 26):
	if i not in a:
		b.append(i)
print("Missing Page numbers :",b)