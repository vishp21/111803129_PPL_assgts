a = int(input("Enter the first term \n"))
r = int(input("Enter the common ratio \n"))
print("The first 10 terms of the Geometric Progression series are:")
for i in range(10):
    print(a)
    a = a * r