import random
dice=[1, 2, 3, 4, 5, 6]
choice=input("Press r to roll the dice or q to quit this game: ")

while not choice == 'q':
   if choice == 'r' :
      random.shuffle(dice)
      print(dice[0])
   choice=input("Press r to roll the dice or q to quit the game: ")