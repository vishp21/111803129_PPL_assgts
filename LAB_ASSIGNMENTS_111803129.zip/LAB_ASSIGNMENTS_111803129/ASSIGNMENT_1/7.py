print("Enter the range in which you want the Armstrong numbers")
i=input()
j=input()
for a in range(int(i), int(j)):
    b=[]
    b=list(map(int, str(a)))
    sum=0
    for m in b:
        sum = sum + m ** len(b)
    if sum == a:
        print(a)