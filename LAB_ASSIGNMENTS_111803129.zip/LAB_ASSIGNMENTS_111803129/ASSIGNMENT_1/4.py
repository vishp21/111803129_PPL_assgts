import random
guesses = 0
print('Hello! What is your name?')

name = input()
number = random.randint(1, 20)
print('Hi, ' + name + ', I am thinking of a number between 1 and 20.')

while guesses < 6:
   print('Take a guess.') 
   guess = input()
   guess = int(guess)
   guesses = guesses + 1

   if guess < number:
      print('Your guess is too low.') 
   if guess > number:
      print('Your guess is too high.')
   if guess == number:
      break
   
if guess == number:
   guesses = str(guesses)
   print('Good job! You have correctly guessed the number')

if guess != number:
   number = str(number)
   print('Sorry, the number I was thinking of was ' + number)
