#include <stdio.h>
int main(){
    int i;
    char a[5];
    for(i = 0; i < 40; i++){
        a[i] = 'A';
    }
    return 0;
}