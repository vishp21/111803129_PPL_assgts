class Cat:
    def __init__(self, color = "", legs = 0):
        self.__color = color
        self.__legs = legs

    def get_color(self):
        return (self.color)

    def get_legs(self):
        return (self.legs)

    def set_color(self, c):
        self.color = c

    def set_legs(self, l):
        self.legs = l

class Dog:
    def __init__(self, color = "", legs = 0):
        self.__color = color
        self.__legs = legs

    def get_color(self):
        return (self.color)

    def get_legs(self):
        return (self.legs)

    def set_color(self, c):
        self.color = c

    def set_legs(self, l):
        self.legs = l

class Rabbit:
    def __init__(self, color = "", legs = 0):
        self.__color = color
        self.__legs = legs

    def get_color(self):
        return (self.color)

    def get_legs(self):
        return (self.legs)

    def set_color(self, c):
        self.color = c

    def set_legs(self, l):
        self.legs = l

class Penguin:
    def __init__(self, color = "", legs = 0):
        self.__color = color
        self.__legs = legs

    def get_color(self):
        return (self.color)

    def get_legs(self):
        return (self.legs)

    def set_color(self, c):
        self.color = c

    def set_legs(self, l):
        self.legs = l

class Elephant:
    def __init__(self, color = "", legs = 0):
        self.__color = color					
        self.__legs = legs

    def get_color(self):
        return (self.color)

    def get_legs(self):
        return  (self.legs)

    def set_color(self, c):
        self.color = c

    def set_legs(self, l):
        self.legs = l

class Tiger:
    def __init__(self, color = "", legs = 0):
        self.__color = color
        self.__legs = legs

    def get_color(self):
        return (self.color)

    def get_legs(self):
        return (self.legs)

    def set_color(self, c):
        self.color = c

    def set_legs(self, l):
        self.legs = l

class Lion:
    def __init__(self, color = "", legs = 0):
        self.__color = color
        self.__legs = legs

    def get_color(self):
        return (self.color)

    def get_legs(self):
        return (self.legs)

    def set_color(self, c):
        self.color = c

    def set_legs(self, l):
        self.legs = l

class Dolphin:
    def __init__(self, color="", legs=0):
        self.__color = color
        self.__legs = legs

    def get_color(self):
        return (self.color)

    def get_legs(self):
        return (self.legs)

    def set_color(self, c):
        self.color = c

    def set_legs(self, l):
        self.legs = l

class Giraffe:
    def __init__(self, color="", legs=0):
        self.__color = color
        self.__legs = legs

    def get_color(self):
        return (self.color)

    def get_legs(self):
        return (self.legs)

    def set_color(self, c):
        self.color = c

    def set_legs(self, l):
        self.legs = l

class Monkey:
    def __init__(self, color="", legs=0):
        self.__color = color
        self.__legs = legs

    def get_color(self):
        return (self.color)

    def get_legs(self):
        return (self.legs)

    def set_color(self, c):
        self.color = c

    def set_legs(self, l):
        self.legs = l

c = Cat()
c.set_color("red")
c.set_legs(4)
print("This cat has", c.get_color(), "color and", c.get_legs(), "legs")

d = Dog()
d.set_color("yellow")
d.set_legs(4)
print("This dog has", d.get_color(), "color and", d.get_legs(), "legs")

r = Rabbit()
r.set_color("blue")
r.set_legs(4)
print("This rabbit has", r.get_color(), "color and", r.get_legs(), "legs")

p = Penguin()
p.set_color("green")
p.set_legs(2)
print("This penguin has", p.get_color(), "color and", p.get_legs(), "legs")

e = Elephant()
e.set_color("orange")
e.set_legs(4)
print("This elephant has", e.get_color(), "color and", e.get_legs(), "legs")

t = Tiger()
t.set_color("purple")
t.set_legs(4)
print("This tiger has", t.get_color(), "color and", t.get_legs(), "legs")

l = Lion()
l.set_color("silver")
l.set_legs(4)
print("This lion has", l.get_color(), "color and", l.get_legs(), "legs")

d = Dolphin()
d.set_color("white")
d.set_legs(0)
print("This dolphin has", d.get_color(), "color and", d.get_legs(), "legs")

g = Giraffe()
g.set_color("black")
g.set_legs(4)
print("This giraffe has", g.get_color(), "color and", g.get_legs(), "legs")

m = Monkey()
m.set_color("grey")
m.set_legs(4)
print("This monkey has", m.get_color(), "color and", m.get_legs(), "legs")